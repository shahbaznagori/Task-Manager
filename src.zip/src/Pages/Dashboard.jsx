import { useEffect, useState } from "react";
import {
  getTasks,
  deleteTask,
  filterTasks,
} from "../api/taskApi";
import TaskForm from "../components/Tasks/TaskForm";
import TaskCard from "../components/Tasks/TaskCard";

export default function Dashboard() {
  const [tasks, setTasks] = useState([]);
  const [editingTask, setEditingTask] = useState(null);

  // Load once after mount
  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    try {
      const data = await getTasks();
      setTasks(data);
    } catch (err) {
      console.log(err);
    }
  };

  const handleDelete = async (id) => {
    await deleteTask(id);
    setTasks((prev) => prev.filter((t) => t._id !== id));
  };

  const handleFilter = async (status) => {
    if (!status) return loadTasks();

    const data = await filterTasks(status);
    setTasks(data);
  };

  const handleTaskSaved = (task) => {
    if (editingTask) {
      setTasks((prev) =>
        prev.map((t) =>
          t._id === task._id ? task : t
        )
      );
      setEditingTask(null);
    } else {
      setTasks((prev) => [task, ...prev]);
    }
  };

  return (
    <div className="p-6">
      {/* Filter On Top */}
      <div className="mb-4">
        <select
          onChange={(e) =>
            handleFilter(e.target.value)
          }
          className="border p-2 rounded"
        >
          <option value="">All</option>
          <option value="pending">Pending</option>
          <option value="completed">
            Completed
          </option>
        </select>
      </div>

      {/* Red Card Form */}
      <TaskForm
        onTaskSaved={handleTaskSaved}
        editingTask={editingTask}
      />

      <div className="space-y-3 mt-6">
        {tasks && tasks.map((task) => (
          <TaskCard
            key={task._id}
            task={task}
            onDelete={handleDelete}
            onEdit={() =>
              setEditingTask(task)
            }
          />
        ))}
      </div>
    </div>
  );
}