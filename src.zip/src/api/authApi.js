import axiosInstance from "./axios";

export const registerUser = async (data) => {
  try {
  const response = await axiosInstance.post("/auth/register", data);
  console.log("RES",response)
    localStorage.setItem("token", response.data.token);

  return response.data;
} catch (error) {
   console.log("ERROR",error.data.message);
}
};

export const loginUser = async (data) => {
  try {
    const response = await axiosInstance.post("/auth/login", data);
    console.log("RES",response);
    localStorage.setItem("token", response.data.token);
    return response.data;
  } catch (error) {
    console.log("ERROR", error.response?.data?.message || "Something went wrong");
    throw error;
  }
};