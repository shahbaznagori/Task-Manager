import axiosInstance from './axios'
// CREATEa
export const createTask = async (data) => {
    try {
        console.log("DATA",data)
      const response = await axiosInstance.post("/tasks", data);
      return response.data.tasks;
    } catch (error) {
      console.log(error);
    }
  };

// READ ALL
export const getTasks = async () => {
    try {
        console.log("DATA")
  const response = await axiosInstance.get("/tasks");
  console.log("RES",response)
  return response.data.tasks;
} catch (error) {
  console.log(error);
}
};

// FILTER
export const filterTasks = async (status) => {
  const response = await axiosInstance.get(
    `/tasks/filter?status=${status}`
  );
  return response.data;
};

// UPDATE
export const updateTask = async (id, data) => {
  const response = await axiosInstance.put(
    `/tasks/${id}`,
    data
  );
  return response.data;
};

// DELETE
export const deleteTask = async (id) => {
  const response = await axiosInstance.delete(
    `/tasks/${id}`
  );
  return response.data;
};
