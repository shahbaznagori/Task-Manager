import { useEffect, useState } from "react";
import {
  createTask,
  updateTask,
} from "../../api/taskApi";

export default function TaskForm({
  onTaskSaved,
  editingTask,
}) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    status: "pending",
  });

  useEffect(() => {
    if (editingTask) {
      setFormData(editingTask);
    }
  }, [editingTask]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.title.trim()) return;

    let savedTask;

    if (editingTask) {
      savedTask = await updateTask(
        editingTask._id,
        formData
      );
    } else {
      savedTask = await createTask(formData);
    }

    onTaskSaved(savedTask);

    setFormData({
      title: "",
      description: "",
      status: "pending",
    });
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-red-100 p-6 rounded shadow"
    >
      <h2 className="font-bold mb-4">
        {editingTask
          ? "Update Task"
          : "Create Task"}
      </h2>

      <input
        name="title"
        placeholder="Title"
        value={formData.title}
        onChange={handleChange}
        className="w-full border p-2 mb-3 rounded"
      />

      <textarea
        name="description"
        placeholder="Description"
        value={formData.description}
        onChange={handleChange}
        className="w-full border p-2 mb-3 rounded"
      />

      <select
        name="status"
        value={formData.status}
        onChange={handleChange}
        className="w-full border p-2 mb-3 rounded"
      >
        <option value="pending">Pending</option>
        <option value="completed">
          Completed
        </option>
      </select>

      <button className="bg-red-600 text-white px-4 py-2 rounded w-full">
        {editingTask
          ? "Update Task"
          : "Add Task"}
      </button>
    </form>
  );
}