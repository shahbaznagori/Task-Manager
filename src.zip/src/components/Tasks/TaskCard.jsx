export default function TaskCard({
  task,
  onDelete,
  onEdit,
}) {
  return (
    <div className="bg-white p-4 rounded shadow flex justify-between">
      <div>
        <h3 className="font-semibold">
          {task.title}
        </h3>
        <p className="text-sm text-gray-600">
          {task.description}
        </p>
        <span className="text-xs">
          {task.status}
        </span>
      </div>

      <div className="space-x-2">
        <button
          onClick={onEdit}
          className="text-blue-600"
        >
          Edit
        </button>
        <button
          onClick={() => onDelete(task._id)}
          className="text-red-600"
        >
          Delete
        </button>
      </div>
    </div>
  );
}